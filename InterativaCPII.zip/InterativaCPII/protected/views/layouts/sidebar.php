<div class="right_column">
	<div class="social">
	    <a target="_blank" href="https://twitter.com/cp2interativa"><img src="http://www.radiocp2interativa.com.br/wp-content/themes/blankslate/img/twitter_icon.png" alt="Twitter Radio Interativa"/></a>
	    <a target="_blank" href="https://www.facebook.com/cp2interativa"><img src="http://www.radiocp2interativa.com.br/wp-content/themes/blankslate/img/facebook_icon.png" alt="Facebook Radio Interativa"/></a>
	    <a target="_blank" href="https://www.youtube.com/channel/UC0qOMx4D_4nFe-6m-syQ7Hg"><img src="http://www.radiocp2interativa.com.br/wp-content/themes/blankslate/img/youtube_icon.png" alt="Youtube Radio Interativa"/></a>
	</div>
	<div class="widget" id="widget_programas">
	    <div class="title">
	        <img alt="Últimos Programas" src="http://www.radiocp2interativa.com.br/wp-content/themes/blankslate/img/widget_recent_entries.jpg"/>
	        <h3>Últimos Programas</h3>
	    </div>
	    <div class="conteudo">
	        <ul>
                <li><a href="http://www.radiocp2interativa.com.br/especial-50-anos-do-golpe-militar/">Especial 50 anos do golpe militar</a></li>
                <li><a href="http://www.radiocp2interativa.com.br/primeira-interacao-07042014/">Primeira Interação</a></li>
        	</ul>
	    </div>
	</div>
	<div id="search-2" class="widget">
		<div class="title">
			<img src="/wp-content/themes/blankslate/img/widget_search.jpg"/>
			<h3>Pesquisar artigos</h3>
		</div>
		<div class="conteudo">
			<form method="get" id="searchform" action="http://www.radiocp2interativa.com.br">
			    <input type="text" placeholder="Pesquisar" id="s" name="s" class="search_text">
			    <input type="submit" id="searchsubmit" value="." class="search_btn">
			    <div style="clear: both"></div>
	    		<div id="search_hints" class="post_preview"></div>
			</form>
		</div>
	</div>
</div>
<div style="clear: both;">