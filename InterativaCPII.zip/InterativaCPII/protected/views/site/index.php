<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>
<div class="page">
	<h3>Seja bem vindo ao site da Rádio CP2 InterAtiva!</h3>
	<p>Mensagem de boas vindas!</p>
</div>