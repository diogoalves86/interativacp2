<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<div class="page">
	<h3>Sobre Nós</h3>

	<p>Texto com a história da rádio.</p>
</div>
